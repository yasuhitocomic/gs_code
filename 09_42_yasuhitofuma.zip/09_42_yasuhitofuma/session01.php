
<?php
session_start();
$_SESSION["name1"]="ys";
$_SESSION["name2"]="fm";