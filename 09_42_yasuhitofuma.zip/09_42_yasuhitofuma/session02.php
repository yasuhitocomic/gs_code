<?php

session_start();
// echo $_SESSION["name1"];
// echo $_SESSION["name2"];

echo session_id();